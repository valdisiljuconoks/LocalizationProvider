define("epi-forms/contentediting/editors/AllowMultiSelectCheckbox", [// dojo
"dojo/_base/declare", "dojo/_base/lang", // epi-cms
"epi/shell/widget/CheckBox"], function ( // dojo
declare, lang, // epi-cms
Checkbox) {
  // module:
  //      epi-forms/contentediting/editors/AllowMultiSelectCheckbox
  // tags:
  //      protected
  return declare([Checkbox], {
    postMixInProperties: function postMixInProperties() {
      // summary:
      //		Set options based on the selections passed through.
      this.inherited(arguments);
      this.connect(this, "_onChange", lang.hitch(this, function (value) {
        this.onFeedValueChange(this.name, value);
      }));
    },
    onFeedValueChange: function onFeedValueChange(propertyName, value) {// summary:
      //		Callback when this widget's value is changed.
      // tags:
      //		callback
    }
  });
});