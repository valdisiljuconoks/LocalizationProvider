define("epi-forms/widget/FormsContentSelectorPlugAndPlay", [// dojo
"dojo/_base/declare", // dijit
"dijit/_CssStateMixin", "dijit/_TemplatedMixin", "dijit/_Widget", // epi.shell
"epi/shell/command/_Command", // epi.cms
"epi-cms/widget/_HasChildDialogMixin", "epi-cms/widget/ContentSelectorPlugAndPlay"], function ( // dojo
declare, // dijit
_CssStateMixin, _TemplatedMixin, _Widget, // epi.shell
_Command, // epi.cms
_HasChildDialogMixin, ContentSelectorPlugAndPlay) {
  return declare([ContentSelectorPlugAndPlay], {
    _setupCommands: function _setupCommands() {
      this.commands = this.commands || [];
      this.commands.every(function (command) {
        this.own(command);
      }.bind(this));
      this.own(this.commands);
    }
  });
});