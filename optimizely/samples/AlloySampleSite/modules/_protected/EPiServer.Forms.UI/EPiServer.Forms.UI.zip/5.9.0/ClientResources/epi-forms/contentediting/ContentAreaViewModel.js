define("epi-forms/contentediting/ContentAreaViewModel", [// dojo
"dojo/_base/lang", "dojo/_base/array", "dojo/_base/declare", // epi
"epi/dependency", "epi-cms/contentediting/viewmodel/ContentAreaViewModel", // resources
"epi/i18n!epi/cms/nls/episerver.cms.components.requiredproperties"], function ( // dojo
lang, array, declare, // epi
dependency, ContentAreaViewModel, // resources
reqPropsResources) {
  // module:
  //      epi-forms/contentediting/ContentAreaViewModel
  // summary:
  //      Extend ContentAreaViewModel class in order to:
  //      - Get metadata of a content type.
  //      - Check if a content type has any required properties.
  // tags:
  //      public
  return declare([ContentAreaViewModel], {
    metadataManager: null,
    postscript: function postscript() {
      this.inherited(arguments);
      this.metadataManager = this.metadataManager || dependency.resolve("epi.shell.MetadataManager");
    },
    _getMetadata: function _getMetadata(parentLink, contentTypeId) {
      // summary:
      //      Get the metadata for the newly created content.
      // parentLink: String
      //      The parent content link.
      // contentTypeId: Number
      //      The content type id.
      // tags:
      //      private
      return this.metadataManager.getMetadataForType("EPiServer.Core.ContentData", {
        parentLink: parentLink,
        contentTypeId: contentTypeId
      });
    },
    _regroupProperties: function _regroupProperties(metadata) {
      // summary:
      //		Regroup properties into required and additional property groups.
      // metadata: Object
      //      The metadata object.
      // tags:
      //		private
      metadata = lang.clone(metadata);
      metadata.layoutType = this._topLevelContainerType;
      array.forEach(metadata.properties, function (prop) {
        var isMandatory = this._isRequiredProperty(metadata, prop);

        prop.originalGroupName = prop.groupName;
        prop.groupName = isMandatory ? "required" : "additional";
      }, this);
      metadata.groups = [{
        name: "required",
        displayUI: true,
        title: reqPropsResources.groups.required,
        uiType: this._groupContainerType
      }, {
        name: "additional",
        displayUI: true,
        title: reqPropsResources.groups.additional,
        uiType: this._groupContainerType
      }];
      return metadata;
    },
    _hasRequiredProperties: function _hasRequiredProperties(metadata) {
      // summary:
      //      Checks if the metadata object contains any required property.
      // metadata: Object
      //      The metadata object.
      // tags:
      //		protected internal
      return array.some(metadata.properties, function (property) {
        return this._isRequiredProperty(metadata, property);
      }, this);
    },
    _isRequired: function _isRequired(property) {
      // summary:
      //      Checks if the given property is required.
      // property: Object
      //      The metadata property.
      // tags:
      //      protected, extension
      return property.settings && property.settings.required;
    },
    _isRequiredProperty: function _isRequiredProperty(metadata, property) {
      // summary:
      //      Checks if the given property is required.
      // description:
      //      A property is considered to be required if is required or it contains required sub properties.
      //      It should also have no value set, is visible, and is not the icontent_name property which is entered outside the properties form.
      // metadata: Object
      //      The metadata object.
      // property: Object
      //      The metadata property.
      // tags:
      //		private
      var isNotSet = !property.additionalValues.hasValue;
      var isShownForEdit = property.showForEdit && array.every(metadata.groups, function (group) {
        // Every group must be either not the property's original group or have displayui true
        return group.name !== property.groupName && group.name !== property.originalGroupName || group.displayUI;
      });
      var hasRequiredChildProperties = array.some(property.properties, function (childProperty) {
        return this._isRequiredProperty(property, childProperty);
      }, this);
      return (this._isRequired(property) || hasRequiredChildProperties) && isNotSet && isShownForEdit && property.name !== "icontent_name";
    }
  });
});