define("epi-forms/widget/TargetPageSelector", [// dojo
"dojo/_base/declare", // epi
"epi-cms/widget/UrlSelector", // epi-addons
"epi-forms/widget/TargetPageEditor"], function ( // dojo
declare, // epi
UrlSelector, // epi-addons
TargetPageEditor) {
  // module:
  //      epi-forms/widget/TargetPageSelector
  // tags:
  //      public
  return declare([UrlSelector], {
    selectorClass: TargetPageEditor
  });
});