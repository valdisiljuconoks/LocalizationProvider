define("epi-addon-tinymce/plugins/epi-paste/epi-paste", [
    "dojo/Deferred",
    "epi-addon-tinymce/tinymce-loader",
    "epi-addon-tinymce/plugins/epi-paste/is-word-content",
    "epi-addon-tinymce/plugins/epi-paste/paste-confirmation-dialog"
], function (
    Deferred,
    tinymce,
    isWordContent,
    pasteConfirmationDialog
) {
    var isPlainTextPaste = false;
    tinymce.PluginManager.add("epi-paste", function (editor) {
        var wordPreProcess;
        function getPastePreprocessFunction() {
            if (wordPreProcess) {
                return new Deferred().resolve(wordPreProcess);
            }

            var result = new Deferred();
            // word-pre-process couldn't be bundled into widget.js and has to be loaded explicitly
            require(["epi-addon-tinymce/word-processor/word-pre-process"], function (wordPreProcessDependency) {
                wordPreProcess = wordPreProcessDependency;
                result.resolve(wordPreProcess);
            });
            return result.promise;
        }

        editor.on("init", (function () {
            isPlainTextPaste = editor.options.get("paste_as_text");
        }));

        editor.on("PastePlainTextToggle", function (event) {
            isPlainTextPaste = event.state;
        });

        editor.on("PreInit", (function () {
            if (editor.removed) {
                return;
            }

            editor.on("paste", (function (e) {
                if (isPlainTextPaste) {
                    return;
                }
                var paste = (e.clipboardData || window.clipboardData).getData("text/html");
                if (!isWordContent(paste)) {
                    return;
                }

                e.preventDefault();
                e.stopPropagation();

                var pasteFromWordImportType = editor.getParam("pasteFromWordImportType");
                if (pasteFromWordImportType === "RemoveFormatting") {
                    getPastePreprocessFunction().then(function (processor) {
                        paste = processor(editor, paste);
                        this.execCommand("mceInsertContent", false, paste);
                    }.bind(this));
                } else if (pasteFromWordImportType === "KeepFormatting") {
                    // keep formatting
                    this.execCommand("mceInsertContent", false, paste);
                } else {
                    pasteConfirmationDialog().then(function (result) {
                        if (!result) {
                            return;
                        }
                        if (result === "Remove") {
                            getPastePreprocessFunction().then(function (processor) {
                                paste = processor(editor, paste);
                                this.execCommand("mceInsertContent", false, paste);
                            }.bind(this));
                        } else {
                            // keep formatting
                            this.execCommand("mceInsertContent", false, paste);
                        }
                    }.bind(this));
                }
            }));
        }));

        return {
            getMetadata: function () {
                return {
                    name: "Paste (optimizely)",
                    url: "https://www.optimizely.com/"
                };
            }
        };
    });
});
