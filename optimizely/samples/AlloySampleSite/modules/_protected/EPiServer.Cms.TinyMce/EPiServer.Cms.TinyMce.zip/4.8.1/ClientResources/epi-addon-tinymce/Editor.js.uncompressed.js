require({cache:{
'url:epi-addon-tinymce/templates/TinyMCEEditor.html':"<div id=\"widget_${id}\">\r\n    <div data-dojo-attach-point=\"notificationsNode\" class=\"tox editor-notification-container\"></div>\r\n    <div style=\"display: inline-block\" data-dojo-attach-point=\"stateNode, tooltipNode\">\r\n        <textarea data-dojo-attach-point=\"editorFrame\" id=\"${id}_editorFrame\" style=\"border: none;\"></textarea>\r\n    </div>\r\n    <div data-dojo-attach-point=\"dndOverlay\" style=\"background: rgba(0, 0, 0, 0.01); position: absolute; left: 0; top: 0; right: 0; bottom: 0; display: none\"></div>\r\n</div>\r\n"}});
define("epi-addon-tinymce/Editor", [
    // dojo
    "dojo/_base/config",
    "dojo/_base/declare",
    "dojo/_base/lang",

    "dojo/aspect",
    "dojo/Deferred",
    "dojo/dom-style",
    "dojo/dom-class",

    "dojo/topic",
    "dojo/when",

    // dijit
    "dijit/_TemplatedMixin",
    "dgrid/util/misc",

    "require",

    // epi
    "epi/dependency",
    "epi/shell/dnd/Target",
    "epi/shell/layout/_LayoutWidget",
    "epi/shell/widget/_ValueRequiredMixin",

    "epi-cms/widget/_HasChildDialogMixin",
    "epi-cms/_ContentContextMixin",
    "epi-cms/contentediting/ContentActionSupport",
    "epi-cms/core/ContentReference",

    "epi-addon-tinymce/tinymce-loader",
    "./FileBrowser",
    "./displayTransformationErrors",
    "./popup-manager-injector",
    "./get-language-mapping",

    // templates
    "dojo/text!./templates/TinyMCEEditor.html",
    // resources
    "epi/i18n!epi/nls/tinymce.editorstyles",
    "epi/i18n!epi/nls/episerver.cms.tinymce",

    // plugins
    "epi-addon-tinymce/plugins/epi-image-uploader/epi-image-uploader",
    "epi-addon-tinymce/plugins/epi-link/epi-link",
    "epi-addon-tinymce/plugins/epi-create-block/epi-create-block",
    "epi-addon-tinymce/plugins/epi-personalized-content/epi-personalized-content",
    "epi-addon-tinymce/plugins/epi-image-editor/epi-image-editor",
    "epi-addon-tinymce/plugins/epi-dnd-processor/epi-dnd-processor",
    "epi-addon-tinymce/plugins/epi-image-tools/epi-image-tools",
    "epi-addon-tinymce/plugins/epi-block-tools/epi-block-tools",
    "epi-addon-tinymce/plugins/epi-paste/epi-paste",

    "xstyle/css!./styles/TinyMCEEditor.css"
], function (
    // dojo
    config,
    declare,
    lang,

    aspect,
    Deferred,
    domStyle,
    domClass,

    topic,
    when,

    // dijit
    _TemplatedMixin,
    misc,

    require,

    // epi
    dependency,
    Target,
    _LayoutWidget,
    _ValueRequiredMixin,

    _HasChildDialogMixin,
    _ContentContextMixin,
    ContentActionSupport,
    ContentReference,

    tinymce,
    fileBrowser,
    displayTransformationErrors,
    PopupManagerInjector,
    getLanguageMapping,

    // templates
    template,
    // resources
    styleResources,
    resources,

    // plugins
    epiImageUploader
) {
    return declare([_LayoutWidget, _TemplatedMixin, _ValueRequiredMixin, _HasChildDialogMixin, _ContentContextMixin], {
        // summary:
        //      Editor for TinyMCE in all properties mode.
        // tags:
        //      internal

        // baseClass: [public] String
        //    The widget's base CSS class.
        baseClass: "epiTinyMCEEditor",

        // width: [public] Number
        //    The editor width.
        width: null,

        // height: [public] Number
        //    The editor height.
        height: null,

        // value: [public] String
        //    The editor content.
        value: null,

        // intermediateChanges: Boolean
        //    Fires onChange for each value change or only on demand
        intermediateChanges: true,

        // templateString: [protected] String
        //    Template for the widget.
        templateString: template,

        // settings: [public, readonly] object
        //    The editor settings.
        settings: null,

        // dirtyCheckInterval: [public] Integer
        //    How often should the widget check if it is dirty and raise onChange event, in milliseconds. The value is by default set to 2000 ms
        dirtyCheckInterval: 2000,

        dropTarget: null,

        // readOnly: [public, readonly] Boolean
        //    Denotes that the editor is read only.
        readOnly: false,

        // isFullScreen: [public] Boolean
        //      Indicates if the editor is in fullscreen mode
        isFullScreen: false,

        // _editorValue: [private] String
        //    The value set to the editor
        _editorValue: null,

        // editorAllowedClass: [public] String
        //    The class used to mark the editor as droppable
        editorAllowedClass: "epiTinyMCEEditorAllowed",

        // editorDraggedClass: [public] String
        //    The class used to mark the editor after dropping an item
        editorDraggedClass: "epiTinyMCEEditorDragged",

        // _messageService: [private] Object
        //      Instance of epi.shell.MessageService
        _messageService: null,

        postCreate: function () {
            this.inherited(arguments);

            this._messageService = this._messageService || dependency.resolve("epi.shell.MessageService");

            this._throttledPlaceCaretAt = misc.throttle(function (x, y) {
                this.editor.selection.placeCaretAt(x, y);

                // Determine if selection is inside a content editable false DOM tree.
                var nonEditableRoot = this._getContentEditableFalseRoot(this.editor.selection.getNode(), this.editor.dom.getRoot());
                if (nonEditableRoot) {
                    // More the selection before the content editable false.
                    var range = this.editor.dom.createRng();
                    range.setStartBefore(nonEditableRoot);
                    range.setEndBefore(nonEditableRoot);
                    this.editor.selection.setRng(range);
                }
            }, this);

            this.own(
                this.dropTarget = new Target(this.dndOverlay, {
                    accept: this.allowedDndTypes,
                    reject: this.restrictedDndTypes,
                    createItemOnDrop: false,
                    readOnly: this.readOnly
                }),
                // Only focus if we enter the overlay.
                aspect.after(this.dropTarget, "onMouseOver", function () {
                    this.editor.focus();
                }.bind(this)),
                aspect.before(this.dropTarget, "onMouseMove", function (e) {
                    if (!this.dropTarget.isDragging) {
                        return;
                    }
                    this.placeCaretAt(e.offsetX, e.offsetY);
                }.bind(this)),
                // On exit, blur the editor since we might not be dropping.
                aspect.before(this.dropTarget, "onMouseOut", function () {
                    if (this.dropTarget.isDragging) {
                        this.set("focused", false);
                        this.onBlur();
                        this.onTinyMceEditorBlur();
                    }
                }.bind(this)),
                topic.subscribe("/dnd/start", this._onDndStart.bind(this)),
                topic.subscribe("/dnd/cancel", this._onDndCancel.bind(this)),
                topic.subscribe("/dnd/drop", this._onDndDrop.bind(this)),
                topic.subscribe("LastFileUploadedAndReplaced", this.refreshImages.bind(this))
            );

            this.connect(this.dropTarget, "onDropData", "onDropData");

            if (this.isInQuickEditMode) {
                this.domNode.style.width = this.settings.width ? this.settings.width + "px" : "500px";
            }
        },

        startup: function () {
            // summary:
            //    Loads the TinyMCE dependencies and initialize the editor.
            //
            // tags:
            //    protected

            if (this._started) {
                return;
            }

            this.inherited(arguments);
            var self = this;

            return this._updateTinySettings(lang.clone(this.settings))
                .then(function (settings) {
                    if (settings.site_styles) {
                        self.resolveSiteStyles(settings);
                    }

                    //disable tinymce auto-promotion button
                    settings.promotion = false;
                    return tinymce.init(settings).then(function () {
                        if (self.readOnly) {
                            self.set("readOnly", true);
                        }
                    });
                });
        },

        destroy: function () {
            // summary:
            //    Destroy TinyMCE widget.
            //
            // tags:
            //    protected

            if (this._destroyed) {
                return;
            }

            var ed = this.editor;

            if (this.isFullScreen) {
                domClass.remove(document.body, "epi-addon-tinymce--fullscreen");
            }

            ed && ed.remove();

            this.inherited(arguments);
        },

        focus: function () {
            var editor = this.editor;
            if (editor && editor.initialized) {
                editor.focus();
            }
        },

        placeCaretAt: function (clientX, clientY) {
            // summary:
            //    Set caret position
            //
            // tags:
            //    protected

            this._throttledPlaceCaretAt(clientX, clientY);
        },

        canAccept: function () {
            return !domClass.contains(this.dndOverlay, "dojoDndTargetDisabled");
        },

        resolveSiteStyles: function (settings) {
            // summary:
            //      Add styles to the site
            // tags:
            //      protected

            if (!settings.content_css) {
                settings.content_css = [];
            }
            settings.site_styles.forEach(function (css) {
                settings.content_css.push(css);
            }, this);
            delete settings.site_styles;
        },

        _getContentEditableFalseRoot: function (node, root) {
            // summary:
            //      Method which traverses up the DOM tree and returns the content editable false root.
            // tags:
            //      private

            var target;

            for (; node && node !== root; node = node.parentNode) {
                if (node.isContentEditable) {
                    return target;
                } else {
                    target = node;
                }
            }

            return target;
        },

        _onDndStart: function () {
            if (!this.editor) {
                return;
            }

            if (!this.editor.inline && this.editor.contentAreaContainer) {
                this.dndOverlay.style.top = this.editor.contentAreaContainer.offsetTop + "px";
            }
            domStyle.set(this.dndOverlay, "display", "block");
            if (!this.canAccept()) {
                domClass.add(this.stateNode, "epi-dropTargetDisabled");
            }
            this.onBlur();
        },

        _onDndCancel: function () {
            domStyle.set(this.dndOverlay, "display", "none");
            domClass.remove(this.stateNode, "epi-dropTargetDisabled");
        },

        _onDndDrop: function () {
            domStyle.set(this.dndOverlay, "display", "none");
            domClass.remove(this.stateNode, "epi-dropTargetDisabled");
        },

        onDropData: function (dndData) {
            //summary:
            //    Handle drop data event.
            //
            // dndData:
            //    Dnd data extracted from the dragging items which have the same data type to the current target
            //
            // source:
            //    The dnd source.
            //
            // nodes:
            //    The dragging nodes.
            //
            // copy:
            //    Denote that the drag is copy.
            //
            // tags:
            //    private

            var dropItem = dndData ? (dndData.length ? dndData[0] : dndData) : null;

            if (!dropItem) {
                return;
            }

            // invoke the onDropping required by SideBySideWrapper and other widgets listening on onDropping
            if (this.onDropping) {
                this.onDropping();
            }

            this.editor.execCommand("mceEPiProcessDropItem", true, dropItem);
            domStyle.set(this.dndOverlay, { display: "none" });
        },

        _setFocusedAttr: function (focused) {
            // summary:
            //    Sets the focused state and triggers a validation.
            // tags:
            //    protected

            this._set("focused", focused);

            // Trigger validation since the valid state is dependant on the focused state.
            this.validate(true);
        },

        _setValueAttr: function (value) {
            // summary:
            //    Sets the editor value.
            // tags:
            //    protected

            var editor = this.editor;

            this._set("value", value);

            // Set the content if the editor has been initialized.
            if (editor && editor.initialized) {
                editor.setContent(value || "");
            }
        },

        _setReadOnlyAttr: function (value) {
            this.readOnly = value;
            if (this.editor) {
                if (this.editor.editorContainer) {
                    var topBarEl = this.editor.editorContainer.querySelector(".mce-top-part");
                    if (topBarEl) {
                        topBarEl.style.display = value ? "none" : "";
                    }
                }
                if (value) {
                    this.editor.mode.set("readonly");
                } else {
                    this.editor.mode.set("design");
                }
            }
        },

        _updateTinySettings: function (settings) {
            var def = new Deferred();

            // If an initialization module module has been defined
            // we run it first
            if (settings.initialization_module) {
                require([settings.initialization_module], function (initModule) {
                    try {
                        var customSettingsPromise = initModule(settings);
                        when(customSettingsPromise).then(function (scriptResult) {
                            def.resolve(scriptResult);
                        });
                    } catch (err) {
                        // Handle errors thrown in the init module
                        console.error(err);
                        def.reject(settings);
                    }
                });
            } else {
                def.resolve(settings);
            }

            // Always apply our settings last, even though the init module does something stupid
            return def.promise
                .always(function (settings) {
                    if (this.readOnly) {
                        settings.toolbar = false;
                        settings.menubar = false;
                    }

                    var defaultSettings = {
                        branding: false,
                        relative_urls: false,
                        target: this.editorFrame,
                        //theme: "modern_episerver",
                        readonly: this.readOnly,
                        language: getLanguageMapping(config.locale),
                        images_upload_handler: function (blobInfo, success, failure, progress) {
                            //TODO: CMS-25250 - Should we allow to turn this off? Before it was a plugin
                            return epiImageUploader(blobInfo, success, this.editor);
                        }.bind(this),
                        setup: function (editor) {
                            this.editor = editor;

                            this._popupManagerInjector = new PopupManagerInjector(this);
                            this.own(this._popupManagerInjector);

                            // _contentlink is passed in by BlockEditFormContainer,
                            // to support inline editing such as in quickEdit and ContentManager
                            if (this._contentLink) {
                                editor._contentLink = this._contentLink;
                            }

                            if (this.isInQuickEditMode) {
                                editor.isInQuickEditMode = this.isInQuickEditMode;
                            }

                            if (typeof this.isEditing === "function") {
                                editor.isEditing = this.isEditing();
                            }

                            when(this.getCurrentContext()).then(function (currentContext) {
                                if (currentContext && currentContext.currentMode === "create") {
                                    editor.isInCreateMode = true;
                                }

                                when(this.getCurrentContent()).then(function (content) {
                                    editor.hasCreateAccessRights = ContentActionSupport.isActionAvailable(content,
                                        ContentActionSupport.action.Create, ContentActionSupport.providerCapabilities.Create, true);
                                });
                            }.bind(this));

                            this._setupEditorEventHandling(editor);
                            this._registerEditorOptions();

                        }.bind(this)
                    };
                    return lang.mixin(fileBrowser(settings), defaultSettings);

                }.bind(this));
        },

        _setupEditorEventHandling: function (editor) {
            // summary:
            //    Hook up to the TinyMCE events.
            // editor:
            //    Instance of the current editor.
            // tags:
            //    protected

            editor.on("init", function () {
                this.own(
                    // notifications should be displayed in custom container
                    aspect.after(editor.notificationManager, "open", function (notification) {
                        var notificationNode = notification.getEl();
                        if (!notificationNode) {
                            return;
                        }

                        this.notificationsNode.appendChild(notificationNode);

                        // handle onclose event manually
                        // since after we change parent it is not bubbled from editor anymore
                        var closeButton = notification.getEl().querySelector(".tox-notification__dismiss");
                        closeButton.addEventListener("click", notification.close);

                        // do not allow to reposition notification
                        notification.reposition = function () { };
                    }.bind(this))
                );

                if (this.editor.inline && this.settings.body_class) {
                    var root = this.editor.dom.getRoot();
                    root.classList.add(this.settings.body_class);
                }

                // Load our custom tinyMCE content css into the tinyMCE iframe
                editor.dom.loadCSS(this.settings.epi_content_css);

                tinymce.addI18n(tinymce.i18n.getCode(), styleResources);
                editor.setContent(this.value || "");
                this.set("_editorValue", this.editor.getContent());

                // Pass the open function for the notification manager
                displayTransformationErrors(editor.notificationManager.open, this.settings.epi_transformation_errors);

                this.onTinyMCEInitialized();
            }.bind(this));

            editor.on("drop", function () {
                // Focus the editor on drop to handle text being dragged to the editor.
                editor.focus();
            });

            editor.on("undo redo", function () {
                editor.fire("Change");
            });

            editor.on("blur", function (eventArgs) {
                this._hasBeenBlurred = true;

                // Do not interfere with focus when the dialog is still being shown.
                if (this.isShowingChildDialog) {
                    return;
                }

                // Ensure the final editor state is set before editing is stopped.
                this._onChange(eventArgs.target.getContent());

                this.set("focused", false);
                this.onBlur();
                this.onTinyMceEditorBlur();
            }.bind(this));

            editor.on("focus", function () {
                this.set("focused", true);
                this.onFocus();
            }.bind(this));

            editor.on("keyup", misc.debounce(this._dirtyCheck, this, this.dirtyCheckInterval));

            var editorOnChange = function (eventArgs) {
                // The callback might be called if the editor was rendered inside a dialog
                // in that case the _onChange would throw an error and we need to exit early
                if (this._destroyed) {
                    return;
                }

                // Changes from dialogs will be handled after dialog gets executed.
                if (this.isShowingChildDialog) {
                    return;
                }

                this._onChange(eventArgs.target.getContent());
            }.bind(this);

            editor.on("Change", misc.debounce(editorOnChange, this, this.dirtyCheckInterval));

            editor.on("OpenWindow", function () {
                this.isShowingChildDialog = true;
            }.bind(this));

            editor.on("CloseWindow", function (eventArgs) {
                this._onChange(eventArgs.target.getContent());
                this.isShowingChildDialog = false;
                this.focus();
            }.bind(this));

            editor.on("SetContent", this._onSetContent.bind(this));
            editor.on("FileDragging", this.onFileDragging.bind(this));
            editor.on("FileDragged", this.onFileDragged.bind(this));
            editor.on("FileStoppedDragging", this.onFileStoppedDragging.bind(this));

            editor.on("FullscreenStateChanged", function (event) {
                this.isFullScreen = event.state;
                domClass.toggle(this.domNode, this.baseClass + "Fullscreen", event.state);
                domClass.toggle(document.body, "epi-addon-tinymce--fullscreen", event.state);
                this.onFullScreenChanged(this.isFullScreen);
            }.bind(this));
        },

        onFileDragging: function () {
            // summary:
            //    A file is being dragged in edit mode
            // tags:
            //    protected callback

            domClass.replace(this.stateNode, this.editorAllowedClass, this.editorDraggedClass);
        },

        onFileDragged: function () {
            // summary:
            //    A file was dragged onto the editor
            // tags:
            //    protected callback

            domClass.replace(this.stateNode, this.editorDraggedClass, this.editorAllowedClass);
        },

        onFileStoppedDragging: function () {
            // summary:
            //    A file was dragged outside edit mode
            // tags:
            //    protected callback

            domClass.remove(this.stateNode, this.editorAllowedClass, this.editorDraggedClass);
        },

        _onSetContent: function (eventArgs) {
            // summary:
            //    Raised when the content is set to the editor.
            // eventArgs:
            //    The event arguments.
            // tags:
            //    callback

            var newValue = eventArgs.target.getContent();

            if (eventArgs.selection) {
                var isSet = eventArgs.set;
                // If new content is set to current selection, raise event to save it!
                if (isSet) {
                    this._onChange(newValue);
                }
            }

            if (this.get("_editorValue") !== newValue) {
                this.validate();
                this.onLayoutChanged();
            }
        },

        validate: function () {
            if (!this.settings.epi_disable_validation) {
                this._validateImageAltText();
            }
            return this.inherited(arguments);
        },

        _validateImageAltText: function () {
            if (!this.editor || !this.editor.dom) {
                return;
            }

            var propertyName = this.params.label || this.params.name;
            var externalId = "warning.image.alt.is.empty" + propertyName;
            var messageTemplate = resources.validation.warning.image.altisempty;

            when(this.getCurrentContext(), function (context) {

                this._messageService.query({ contextId: context.id, externalItemId: externalId }).forEach(function (item) {
                    this._messageService.remove({ id: item.id });
                }.bind(this));

                var images = this.editor.dom.getRoot().getElementsByTagName("img");

                for (var i = 0; i < images.length; i++) {
                    var img = images[i];
                    if (img.alt.trim() === "") {
                        this._messageService.put("warn",
                            messageTemplate
                                .replace("${name}", img.src.split("/").reverse().shift().split(",").shift())
                                .replace("${property}", propertyName),
                            "epi.cms.contentdata", context.id, externalId);
                    }
                }
            }.bind(this));
        },

        _onChange: function (val) {
            // summary:
            //    Raised when the editor's content is changed.
            //
            // val:
            //    The editor's changed value
            //
            // tags:
            //    callback

            var hasChanged = this.get("_editorValue") !== val;

            if (hasChanged) {
                this._set("value", val);
                this.set("_editorValue", val);

                if (this.validate()) {
                    this.onChange(val);
                }
            }
        },

        onChange: function () {
            // summary:
            //      Called when the value of the editor has changed.
            // tags:
            //      callback
        },

        onFullScreenChanged: function (isFullScreen) {
            // summary:
            //      Called when the fullscreen state is changed
            // tags:
            //      callback
        },

        onTinyMCEInitialized: function () {
            // summary:
            //      Called when the tinymce was initialized.
            // tags:
            //      callback
        },

        _onBlur: function () {
            // TinyMCE should handle its own focus and blur events.
        },

        onTinyMceEditorBlur: function () {
            // summary:
            //      Called when the tinymce editor was blured
            // tags:
            //      callback
        },

        _onFocus: function () {
            // TinyMCE should handle its own focus and blur events.
        },

        _dirtyCheck: function () {
            // summary:
            //    Check if the editor is dirty and raise onChange event.
            //
            // tags:
            //    private

            // The dirty check might be called after the editor has been destroyed
            // because of the keyup debounce
            if (this._destroyed) {
                return;
            }
            this._onChange(this.editor.getContent());
        },

        contextChanged: function () {
            if (this.editor.windowManager) {
                this.editor.windowManager.close();
            }
        },

        refreshImages: function () {
            this.editor.contentDocument.querySelectorAll("img").forEach(function (img) {
                if (!img.src) {
                    return;
                }

                img.src = img.src + "#" + new Date().getTime();
            });
        },

        _registerEditorOptions: function () {
            // summary:
            //    register settings as TinyMCE options

            (this.editorOptionsToRegister || []).map(function (option) {
                this.editor.options.register(option, {
                    processor: function () {
                        return true;
                    },
                    "default": this.settings[option]
                });
            }.bind(this));
        }
    });
});
