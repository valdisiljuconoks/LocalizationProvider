define("epi-addon-tinymce/EditorWrapper", [
// dojo
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/dom-style",
    "dojo/dom-construct",
    "dojo/dom-class",
    "dojo/on",
    "dojo/when",
    "dojo/Deferred",
    "dojo/aspect",
    // epi
    "epi/debounce",
    "epi-cms/contentediting/InlineEditorWrapper",
    "epi/shell/DestroyableByKey",
    "./tinymce-loader"
],

function (
// dojo
    declare,
    lang,
    domStyle,
    domConstruct,
    domClass,
    on,
    when,
    Deferred,
    aspect,
    // epi
    debounce,
    InlineEditorWrapper,
    DestroyableByKey,
    tinymce
) {

    return declare([InlineEditorWrapper, DestroyableByKey], {
        // summary:
        //      Overlay based inline editor wrapper for rich text editor.
        // tags:
        //      internal

        _toolbarPositionHandleKey: "toolbarPositionHandle",

        // isUndoDisabled: [readonly] boolean
        //      Flag used to disable undo when the editor is running.
        isUndoDisabled: true,

        postCreate: function () {
            this.inherited(arguments);

            this.own(
                on(this.get("iframeWithOverlay").iframe, "unload", function () {
                    this.tryToStopEditing();
                }.bind(this))
            );
        },

        destroy: function () {
            this.inherited(arguments);

            this._removeHandles();
        },

        focus: function () {
            // summary:
            //      Setup pre-settings when focus
            // tags:
            //      public, extension

            this.inherited(arguments);

            this.blockDisplayNode && domStyle.set(this.blockDisplayNode, { visibility: "hidden" });

            this._toggleOverlayItemZIndex(true);
            this._toggleSupportCustomDnd(true);
        },

        startEdit: function () {
            // summary:
            //      Updates editor widget parameters when start edit
            // tags:
            //      public, extension

            this.inherited(arguments);

            var overlayContainer = this.overlayItem.parent.domNode.parentElement;

            when(this._getOrCreateEditor()).then(function () {
                this.editorWidget.focus();

                var updateToolbarPosition = function () {
                    this.toolbarContainer = document.querySelector("#" + this.overlayItem.domNode.id + " .tox-editor-header");
                    if (!this.toolbarContainer) {
                        return;
                    }

                    // exit if in fullScreen mode
                    if (this.editorWidget.isFullScreen) {
                        return;
                    }

                    this.toolbarContainer.style.position = "fixed";
                    var overlayContainerPosition = this.overlayItem.domNode.closest(".epi-cardContainer-child").getBoundingClientRect();

                    var overlayPosition = this.overlayItem.domNode.getBoundingClientRect();

                    this.toolbarContainer.style.width = this.overlayItem.domNode.clientWidth + "px";
                    this.toolbarContainer.style.left = overlayPosition.x + "px";

                    var y = Math.max(overlayContainerPosition.y, overlayPosition.y) - this.toolbarContainer.clientHeight;
                    if (y < 40) {
                        y = 40;
                    }
                    this.toolbarContainer.style.top = y + "px";
                }.bind(this);

                // Set the initial toolbar position once the editor is initialized.
                this.ownByKey(this._toolbarPositionHandleKey,
                    on(this.editorWidget, "tinyMCEInitialized", updateToolbarPosition),
                    on(overlayContainer, "scroll", debounce(updateToolbarPosition)),
                    on(this.editorWidget, "fileDragged", function () {
                        domClass.replace(this.overlayItem.containerNode, this.editorWidget.editorDraggedClass, this.editorWidget.editorAllowedClass);
                    }.bind(this)),
                    on(this.editorWidget, "fileDragging", function () {
                        domClass.replace(this.overlayItem.containerNode, this.editorWidget.editorAllowedClass, this.editorWidget.editorDraggedClass);
                    }.bind(this)),
                    on(this.editorWidget, "fileStoppedDragging", function () {
                        domClass.remove(this.overlayItem.containerNode, this.editorWidget.editorAllowedClass, this.editorWidget.editorDraggedClass);
                    }.bind(this)),
                    on(this.editorWidget, "fullScreenChanged", function (fullScreen) {
                        if (fullScreen) {
                            this.toolbarContainer.style.position = "";
                            this.toolbarContainer.style.width = "";
                        } else {
                            this.toolbarContainer.style.position = "fixed";
                            updateToolbarPosition();
                        }
                    }.bind(this)),
                    on(this.get("iframeWithOverlay"), "viewportresized, viewportpulldown", debounce(updateToolbarPosition)),
                    aspect.after(this.overlayItem, "updatePosition", debounce(updateToolbarPosition))
                );

                updateToolbarPosition();
            }.bind(this));
        },

        _onEditorResizing: function (/*Object*/resizeInfo) {
            // summary:
            //      Stub to do something when the current editor on resizing progress
            // resizeInfo: [Object]
            //      Object that provides resize information to editor wrapper
            // tags:
            //      protected, extension

            this.blockDisplayNode && domStyle.set(this.blockDisplayNode, resizeInfo.style);
        },

        _onEditorResized: function (/*Function*/callbackFunction) {
            // summary:
            //      Stub to do something when the current editor finished its resizing process
            // tags:
            //      protected, extension

            var overlayItem = this.get("overlayItem");
            overlayItem && overlayItem.onResize();

            callbackFunction && this.defer(callbackFunction, 100);
        },

        _removeHandles: function () {
            // summary:
            //      Removes registered handles
            // tags:
            //      private

            this.destroyByKey(this._toolbarPositionHandleKey);
        },

        _removeEditingFeatures: function () {
            // summary:
            //      Its purpose is to restore state as it was before editing was started.
            // tags:
            //      protected, extension

            this.inherited(arguments);

            // Restore the block display node's styles
            this.blockDisplayNode && domStyle.set(this.blockDisplayNode, {
                height: "auto",
                visibility: "visible"
            });

            // Restore z-index of the overlay item
            this._toggleOverlayItemZIndex();
            // Remove custom Dnd
            this._toggleSupportCustomDnd();
            this._removeHandles();
        },

        _onClick: function (e) {
            // tags:
            //      internal xproduct

            if (e.target.tagName !== "A") {
                this.inherited(arguments);
            }
            this.editorWidget.focus();
        }
    });
});
