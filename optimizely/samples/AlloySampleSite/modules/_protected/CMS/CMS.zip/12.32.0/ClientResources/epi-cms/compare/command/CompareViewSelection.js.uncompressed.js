define("epi-cms/compare/command/CompareViewSelection", [
    "dojo/_base/declare",
    // Parent class
    "epi/shell/command/OptionCommand",
    "epi-cms/command/_NonEditViewCommandMixin"
], function (
    declare,
    // Parent class
    OptionCommand,
    _NonEditViewCommandMixin
) {

    return declare([OptionCommand, _NonEditViewCommandMixin], {
        // summary:
        //      A command for selecting the current compare view
        // tags:
        //      internal

        _selectedSetter: function (selected) {
            // summary:
            //      Overridden to set iconClass and tooltip based on the currently selected option
            this.inherited(arguments);
            this.get("options").some(function (option) {
                if (option.value === selected) {
                    this.set("iconClass", option.iconClass);
                    return true;
                }
            }, this);
        },

        _viewChanged: function (type, args, data) {
            var onPageOption = "sidebysidecompare";
            if (data && data.hideView) {
                var filteredOptions = this.get("options").filter(function (option) {
                    return option.value !== onPageOption; //Filter the On-page option if the content has no view
                });

                this.set("options", filteredOptions);

                if (this.selected === onPageOption) {
                    this.set("selected",filteredOptions[0].value);
                }
            } else {
                // set options to null to reset the options to the original option list (modeOptions)
                this.set("options", null);
            }

            // re-set model.enabled value so that the Compare mode selector get updated
            var enabled = this.model.get("enabled");
            if (enabled) {
                this.model.set("enabled", enabled, false);
            }
        }
    });
});
