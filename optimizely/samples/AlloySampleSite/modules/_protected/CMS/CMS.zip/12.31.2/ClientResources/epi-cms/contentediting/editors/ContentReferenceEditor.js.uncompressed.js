require({cache:{
'url:epi-cms/contentediting/editors/templates/ContentReferenceEditor.html':"<div class=\"dijitInline\" tabindex=\"-1\" role=\"presentation\">\r\n    <div data-dojo-type=\"epi-cms/contentediting/AllowedTypesList\"\r\n            data-dojo-props=\"allowedTypes: this.allowedTypes, restrictedTypes: this.restrictedTypes, defaultAllowedTypes: this.defaultAllowedTypes\"\r\n            data-dojo-attach-point=\"allowedTypesHeader\"></div>\r\n    <div data-dojo-attach-point=\"container,dropAreaNode\"></div>\r\n</div>\r\n"}});
define("epi-cms/contentediting/editors/ContentReferenceEditor", [
    // dojo
    "dojo/_base/declare",
    "dojo/on",
    "dojo/when",

    // epi
    "epi/shell/TypeDescriptorManager",

    // epi.cms
    "epi-cms/widget/SelectorWrapperBase",
    "epi-cms/core/ContentReference",
    "epi-cms/widget/_ContentSelectorActionsMixin",
    "epi-cms/widget/ContentSelector",
    "epi-cms/widget/MediaSelector",
    "epi-cms/widget/ThumbnailSelector",
    "epi-cms/contentediting/AllowedTypesList",
    "epi-cms/contentediting/command/BlockInlineEdit",

    // resources
    "dojo/text!./templates/ContentReferenceEditor.html"
], function (
    // dojo
    declare,
    on,
    when,

    // epi
    TypeDescriptorManager,

    // epi.cms
    SelectorWrapperBase,
    ContentReference,
    _ContentSelectorActionsMixin,
    ContentSelector,
    MediaSelector,
    ThumbnailSelector,
    AllowedTypesList,
    BlockInlineEdit,

    // resources
    template
) {

    return declare([SelectorWrapperBase], {
        // summary:
        //    Represents the widget to select ContentReference.
        // tags:
        //      internal xproduct

        templateString: template,

        baseClass: "epi-content-reference-wrapper",

        hideAllowedTypesList: false,

        postMixInProperties: function () {
            // summary:
            //    Initialize properties
            // tags:
            //    protected

            this.selectorClass = this._getContentSelectorType();
            this.inherited(arguments);
        },

        buildRendering: function () {
            // summary:
            //    Creates and append the input hidden field to the dom to preserve the contentLink id
            // tags:
            //    protected

            this.inherited(arguments);
            this.own(
                on(this.domNode, "dblclick", function () {
                    if (this.selector && this.selector.model && this.selector.model.capabilities && this.selector.model.capabilities.isBlock) {
                        var inlineEditCommand = new BlockInlineEdit();
                        when(inlineEditCommand.updateModel(this.selector.model)).then(function () {
                            inlineEditCommand.execute();
                        });
                    }
                }.bind(this))
            );
        },

        _onSelectorValueChange: function (contentLink) {
            if (!ContentReference.compareIgnoreVersion(this.value, contentLink)) {
                this.onFocus();
                this.value = contentLink;
                this._triggerSave();
            }
        },

        _getContentSelectorType: function () {
            if (this._isSelectorFor("episerver.core.icontentimage")) {
                return ThumbnailSelector;
            }

            if (this._isSelectorFor("episerver.core.icontentmedia") || this._isSelectorFor("episerver.core.icontentvideo")) {
                return declare([MediaSelector, _ContentSelectorActionsMixin], {});
            }

            return declare([ContentSelector, _ContentSelectorActionsMixin], {});
        },

        _isSelectorFor: function (typeIdentifier) {
            // summary:
            //      Determine which editor descriptor is used

            return !this.hideAllowedTypesList && this.allowedTypes && this.allowedTypes.length > 0 && this.allowedTypes.every(function (allowedType) {
                return TypeDescriptorManager.isBaseTypeIdentifier(allowedType, typeIdentifier);
            });
        }
    });
});
