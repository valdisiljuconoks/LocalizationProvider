define(
"dojox/atom/widget/nls/fr/FeedViewerEntry", ({
	deleteButton: "[Supprimer]"
})
);
