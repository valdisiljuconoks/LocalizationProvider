define(
"dojox/atom/widget/nls/he/FeedEntryViewer", ({
	displayOptions: "[אפשרויות הצגה]",
	title: "כותרת",
	authors: "מחברים",
	contributors: "תורמים",
	id: "זיהוי",
	close: "[סגירה]",
	updated: "עודכן",
	summary: "סיכום",
	content: "תוכן"
})
);
