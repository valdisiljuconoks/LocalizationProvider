define(
"dojox/atom/widget/nls/da/FeedViewerEntry", ({
	deleteButton: "[Slet]"
})
);
