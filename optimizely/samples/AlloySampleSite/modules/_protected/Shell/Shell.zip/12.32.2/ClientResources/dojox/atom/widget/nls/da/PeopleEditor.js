//>>built
define("dojox/atom/widget/nls/da/PeopleEditor",({add:"Tilføj",addAuthor:"Tilføj forfatter",addContributor:"Tilføj bidragyder"}));