//>>built
define("epi-addon-tinymce/layers/widgets",["epi-addon-tinymce/TinyMCEEditor","epi-addon-tinymce/TinyMCEInlineEditor","epi-addon-tinymce/TinyMCEOverlayItem"],1);